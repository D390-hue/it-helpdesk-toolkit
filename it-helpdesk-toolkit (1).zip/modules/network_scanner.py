"""
network_scanner.py
Scan réseau : ping sweep + scan de ports courants.
"""

import socket
import subprocess
import platform
import ipaddress
import concurrent.futures
from datetime import datetime

CYAN  = "\033[96m"
GREEN = "\033[92m"
RED   = "\033[91m"
YELLOW= "\033[93m"
BOLD  = "\033[1m"
DIM   = "\033[2m"
RESET = "\033[0m"

# Ports courants en environnement IT d'entreprise
COMMON_PORTS = {
    21:   "FTP",
    22:   "SSH",
    23:   "Telnet",
    25:   "SMTP",
    53:   "DNS",
    80:   "HTTP",
    110:  "POP3",
    135:  "RPC",
    139:  "NetBIOS",
    143:  "IMAP",
    389:  "LDAP (Active Directory)",
    443:  "HTTPS",
    445:  "SMB",
    636:  "LDAPS",
    993:  "IMAPS",
    995:  "POP3S",
    3306: "MySQL",
    3389: "RDP (Bureau à distance)",
    5985: "WinRM HTTP",
    8080: "HTTP alternatif",
}


class NetworkScanner:

    def ping(self, host: str) -> bool:
        """Teste si un hôte répond au ping."""
        param = "-n" if platform.system().lower() == "windows" else "-c"
        cmd = ["ping", param, "1", "-W", "1", str(host)]
        try:
            result = subprocess.run(cmd, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, timeout=3)
            return result.returncode == 0
        except Exception:
            return False

    def scan_port(self, host: str, port: int) -> bool:
        """Vérifie si un port TCP est ouvert."""
        try:
            with socket.create_connection((str(host), port), timeout=1):
                return True
        except Exception:
            return False

    def get_hostname(self, ip: str) -> str:
        """Résolution DNS inverse."""
        try:
            return socket.gethostbyaddr(str(ip))[0]
        except Exception:
            return "–"

    def scan_host(self, ip):
        """Scan complet d'un hôte : ping + ports."""
        ip_str = str(ip)
        if not self.ping(ip_str):
            return None

        hostname = self.get_hostname(ip_str)
        open_ports = {}

        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
            futures = {ex.submit(self.scan_port, ip_str, p): p for p in COMMON_PORTS}
            for future in concurrent.futures.as_completed(futures):
                port = futures[future]
                if future.result():
                    open_ports[port] = COMMON_PORTS[port]

        return {"ip": ip_str, "hostname": hostname, "ports": open_ports}

    def run(self, target: str):
        """Lance le scan sur une IP ou une plage CIDR."""
        print(f"{DIM}  Démarrage du scan : {target}{RESET}")
        print(f"{DIM}  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{RESET}\n")

        try:
            # Plage CIDR (ex: 192.168.1.0/24)
            if "/" in target:
                network = ipaddress.ip_network(target, strict=False)
                hosts = list(network.hosts())
                print(f"  Scan de {len(hosts)} hôtes...\n")

                results = []
                with concurrent.futures.ThreadPoolExecutor(max_workers=50) as ex:
                    futures = {ex.submit(self.scan_host, ip): ip for ip in hosts}
                    done = 0
                    for future in concurrent.futures.as_completed(futures):
                        done += 1
                        print(f"\r  Progression : {done}/{len(hosts)}", end="", flush=True)
                        result = future.result()
                        if result:
                            results.append(result)

                print(f"\n\n{BOLD}  Hôtes actifs trouvés : {len(results)}{RESET}\n")
                for r in sorted(results, key=lambda x: x["ip"]):
                    self._print_host(r)

            else:
                # IP unique
                print(f"  Scan de {target}...\n")
                result = self.scan_host(target)
                if result:
                    self._print_host(result)
                else:
                    print(f"{RED}  ✘ Hôte injoignable ou ne répond pas au ping.{RESET}")

        except ValueError as e:
            print(f"{RED}  Adresse invalide : {e}{RESET}")

    def _print_host(self, r: dict):
        """Affiche les résultats d'un hôte."""
        print(f"  {GREEN}●{RESET} {BOLD}{r['ip']}{RESET}  {DIM}({r['hostname']}){RESET}")
        if r["ports"]:
            for port, service in sorted(r["ports"].items()):
                icon = "🔓" if port in [23, 80, 139, 3389] else "🔵"
                print(f"      {icon}  {CYAN}{port:5}{RESET}  {service}")
        else:
            print(f"      {DIM}Aucun port courant ouvert.{RESET}")
        print()
