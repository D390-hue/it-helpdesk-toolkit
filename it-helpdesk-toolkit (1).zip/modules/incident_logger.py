"""
incident_logger.py
Gestionnaire d'incidents style GLPI — stockage JSON local.
"""

import json
import os
import datetime

CYAN  = "\033[96m"
GREEN = "\033[92m"
YELLOW= "\033[93m"
RED   = "\033[91m"
BOLD  = "\033[1m"
DIM   = "\033[2m"
RESET = "\033[0m"

PRIORITIES = {"1": "Basse", "2": "Moyenne", "3": "Haute"}
PRIORITY_COLORS = {"1": DIM, "2": YELLOW, "3": RED}

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "logs", "incidents.json")


class IncidentLogger:

    def __init__(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        if not os.path.exists(DB_PATH):
            self._save([])

    def _load(self) -> list:
        try:
            with open(DB_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []

    def _save(self, data: list):
        with open(DB_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _next_id(self, data: list) -> str:
        if not data:
            return "TKT-0001"
        last_ids = [int(t["id"].split("-")[1]) for t in data]
        return f"TKT-{max(last_ids)+1:04d}"

    def create(self, titre: str, categorie: str, priorite: str,
               description: str, utilisateur: str) -> str:
        data = self._load()
        ticket_id = self._next_id(data)
        now = datetime.datetime.now().isoformat()

        ticket = {
            "id":           ticket_id,
            "titre":        titre,
            "categorie":    categorie or "AUTRE",
            "priorite":     PRIORITIES.get(priorite, "Moyenne"),
            "description":  description,
            "utilisateur":  utilisateur,
            "statut":       "OUVERT",
            "cree_le":      now,
            "mis_a_jour_le": now,
            "resolu_le":    None,
            "resolution":   None,
        }
        data.append(ticket)
        self._save(data)
        return ticket_id

    def close(self, ticket_id: str, resolution: str):
        data = self._load()
        found = False
        for t in data:
            if t["id"].lower() == ticket_id.lower():
                t["statut"] = "CLOTURE"
                t["resolution"] = resolution
                t["resolu_le"] = datetime.datetime.now().isoformat()
                t["mis_a_jour_le"] = datetime.datetime.now().isoformat()
                found = True
                break
        if found:
            self._save(data)
            print(f"\n{GREEN}  ✔ Ticket {ticket_id} clôturé avec succès.{RESET}")
        else:
            print(f"\n{RED}  ✘ Ticket {ticket_id} introuvable.{RESET}")

    def list_all(self):
        data = self._load()
        if not data:
            print(f"  {DIM}Aucun incident enregistré.{RESET}")
            return
        print(f"\n  {BOLD}{'ID':<12} {'STATUT':<10} {'PRIORITÉ':<10} {'CATÉG.':<8} {'TITRE':<30} {'UTILISATEUR'}{RESET}")
        print(f"  {'─'*90}")
        for t in sorted(data, key=lambda x: x["cree_le"], reverse=True):
            s_color = GREEN if t["statut"] == "CLOTURE" else YELLOW
            p_color = PRIORITY_COLORS.get(
                [k for k,v in PRIORITIES.items() if v == t["priorite"]][0]
                if t["priorite"] in PRIORITIES.values() else "2", DIM)
            print(f"  {CYAN}{t['id']:<12}{RESET}"
                  f" {s_color}{t['statut']:<10}{RESET}"
                  f" {p_color}{t['priorite']:<10}{RESET}"
                  f" {t['categorie']:<8}"
                  f" {t['titre'][:30]:<30}"
                  f" {t['utilisateur']}")

    def list_open(self):
        data = self._load()
        open_tickets = [t for t in data if t["statut"] == "OUVERT"]
        if not open_tickets:
            print(f"  {GREEN}  ✔ Aucun incident ouvert !{RESET}")
            return
        print(f"\n  {BOLD}Incidents ouverts ({len(open_tickets)}) :{RESET}\n")
        for t in sorted(open_tickets, key=lambda x: x["cree_le"]):
            p_color = PRIORITY_COLORS.get(
                [k for k,v in PRIORITIES.items() if v == t["priorite"]][0]
                if t["priorite"] in PRIORITIES.values() else "2", DIM)
            print(f"  {CYAN}{BOLD}{t['id']}{RESET}  [{p_color}{t['priorite']}{RESET}]  {t['titre']}")
            print(f"         Utilisateur : {t['utilisateur']}  |  Catégorie : {t['categorie']}")
            print(f"         Créé le : {t['cree_le'][:16].replace('T',' ')}")
            if t["description"]:
                print(f"         {DIM}{t['description'][:70]}{RESET}")
            print()

    def get_all(self) -> list:
        return self._load()

    def get_stats(self) -> dict:
        data = self._load()
        total  = len(data)
        open_  = sum(1 for t in data if t["statut"] == "OUVERT")
        closed = sum(1 for t in data if t["statut"] == "CLOTURE")
        by_cat = {}
        for t in data:
            cat = t.get("categorie", "AUTRE")
            by_cat[cat] = by_cat.get(cat, 0) + 1
        return {"total": total, "open": open_, "closed": closed, "by_category": by_cat}
