"""
system_info.py
Collecte et affiche les informations système de la machine locale.
"""

import platform
import socket
import psutil
import datetime

CYAN  = "\033[96m"
GREEN = "\033[92m"
YELLOW= "\033[93m"
RED   = "\033[91m"
BOLD  = "\033[1m"
DIM   = "\033[2m"
RESET = "\033[0m"


def _bar(percent: float, width: int = 20) -> str:
    """Barre de progression ASCII."""
    filled = int(width * percent / 100)
    color = GREEN if percent < 70 else (YELLOW if percent < 90 else RED)
    bar = "█" * filled + "░" * (width - filled)
    return f"{color}{bar}{RESET} {percent:.1f}%"


class SystemInfo:

    def collect(self) -> dict:
        """Collecte toutes les informations système."""
        # OS
        os_info = {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "hostname": socket.gethostname(),
            "fqdn": socket.getfqdn(),
        }

        # CPU
        cpu_info = {
            "name": platform.processor() or "N/A",
            "cores_physical": psutil.cpu_count(logical=False),
            "cores_logical": psutil.cpu_count(logical=True),
            "usage_percent": psutil.cpu_percent(interval=1),
            "freq": psutil.cpu_freq(),
        }

        # RAM
        ram = psutil.virtual_memory()
        ram_info = {
            "total_gb": ram.total / (1024**3),
            "used_gb":  ram.used  / (1024**3),
            "free_gb":  ram.available / (1024**3),
            "percent":  ram.percent,
        }

        # Disques
        disks = []
        for part in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(part.mountpoint)
                disks.append({
                    "device":    part.device,
                    "mountpoint": part.mountpoint,
                    "fstype":    part.fstype,
                    "total_gb":  usage.total / (1024**3),
                    "used_gb":   usage.used  / (1024**3),
                    "free_gb":   usage.free  / (1024**3),
                    "percent":   usage.percent,
                })
            except PermissionError:
                continue

        # Réseau
        interfaces = []
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        for name, addr_list in addrs.items():
            for addr in addr_list:
                if addr.family == socket.AF_INET:
                    up = stats[name].isup if name in stats else False
                    interfaces.append({
                        "name":    name,
                        "ip":      addr.address,
                        "netmask": addr.netmask,
                        "status":  "UP" if up else "DOWN",
                    })

        # Uptime
        boot_time = datetime.datetime.fromtimestamp(psutil.boot_time())
        uptime = datetime.datetime.now() - boot_time

        return {
            "os":         os_info,
            "cpu":        cpu_info,
            "ram":        ram_info,
            "disks":      disks,
            "interfaces": interfaces,
            "boot_time":  boot_time,
            "uptime":     uptime,
            "collected_at": datetime.datetime.now(),
        }

    def display(self):
        """Affiche les informations système de façon lisible."""
        data = self.collect()

        # OS
        print(f"  {BOLD}{CYAN}── SYSTÈME D'EXPLOITATION ─────────────────────{RESET}")
        o = data["os"]
        print(f"  Nom d'hôte   : {BOLD}{o['hostname']}{RESET}")
        print(f"  FQDN         : {o['fqdn']}")
        print(f"  OS           : {o['system']} {o['release']}")
        print(f"  Architecture : {o['machine']}")
        print(f"  Démarré le   : {data['boot_time'].strftime('%d/%m/%Y %H:%M')}")
        uptime = data["uptime"]
        h, rem  = divmod(int(uptime.total_seconds()), 3600)
        m, _    = divmod(rem, 60)
        print(f"  Uptime       : {h}h {m}min\n")

        # CPU
        print(f"  {BOLD}{CYAN}── PROCESSEUR ─────────────────────────────────{RESET}")
        c = data["cpu"]
        freq_str = f"{c['freq'].current:.0f} MHz" if c["freq"] else "N/A"
        print(f"  Modèle       : {c['name'][:55]}")
        print(f"  Cœurs        : {c['cores_physical']} physiques / {c['cores_logical']} logiques")
        print(f"  Fréquence    : {freq_str}")
        print(f"  Utilisation  : {_bar(c['usage_percent'])}\n")

        # RAM
        print(f"  {BOLD}{CYAN}── MÉMOIRE RAM ────────────────────────────────{RESET}")
        r = data["ram"]
        print(f"  Total        : {r['total_gb']:.1f} Go")
        print(f"  Utilisée     : {r['used_gb']:.1f} Go")
        print(f"  Disponible   : {r['free_gb']:.1f} Go")
        print(f"  Utilisation  : {_bar(r['percent'])}\n")

        # Disques
        print(f"  {BOLD}{CYAN}── DISQUES ────────────────────────────────────{RESET}")
        for d in data["disks"]:
            print(f"  {d['device']} ({d['mountpoint']}) — {d['fstype']}")
            print(f"    Total : {d['total_gb']:.1f} Go  |  Libre : {d['free_gb']:.1f} Go")
            print(f"    Usage : {_bar(d['percent'])}")
        print()

        # Réseau
        print(f"  {BOLD}{CYAN}── INTERFACES RÉSEAU ──────────────────────────{RESET}")
        for iface in data["interfaces"]:
            status_color = GREEN if iface["status"] == "UP" else RED
            print(f"  {BOLD}{iface['name']}{RESET}  [{status_color}{iface['status']}{RESET}]")
            print(f"    IP      : {iface['ip']}")
            print(f"    Masque  : {iface['netmask']}")
        print()
