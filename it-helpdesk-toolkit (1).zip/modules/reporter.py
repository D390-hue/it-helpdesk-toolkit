"""
reporter.py
Génère un rapport HTML complet : infos système + statistiques incidents.
"""

import os
import datetime

REPORTS_DIR = os.path.join(os.path.dirname(__file__), "..", "reports")


class Reporter:

    def __init__(self, incident_logger, system_info):
        self.incidents = incident_logger
        self.sysinfo   = system_info
        os.makedirs(REPORTS_DIR, exist_ok=True)

    def generate(self) -> str:
        now      = datetime.datetime.now()
        filename = f"rapport_{now.strftime('%Y%m%d_%H%M%S')}.html"
        path     = os.path.join(REPORTS_DIR, filename)

        sys_data   = self.sysinfo.collect()
        stats      = self.incidents.get_stats()
        all_tickets = self.incidents.get_all()

        o     = sys_data["os"]
        cpu   = sys_data["cpu"]
        ram   = sys_data["ram"]
        disks = sys_data["disks"]
        ifaces = sys_data["interfaces"]

        freq_str = f"{cpu['freq'].current:.0f} MHz" if cpu["freq"] else "N/A"

        # ── Tickets table rows ──
        rows_html = ""
        status_map = {"OUVERT": "#e67e22", "CLOTURE": "#27ae60"}
        for t in sorted(all_tickets, key=lambda x: x["cree_le"], reverse=True):
            color = status_map.get(t["statut"], "#888")
            rows_html += f"""
            <tr>
              <td><code>{t['id']}</code></td>
              <td>{t['titre']}</td>
              <td>{t['categorie']}</td>
              <td>{t['priorite']}</td>
              <td><span style="color:{color};font-weight:600">{t['statut']}</span></td>
              <td>{t['utilisateur']}</td>
              <td>{t['cree_le'][:16].replace('T',' ')}</td>
            </tr>"""

        # ── Disk rows ──
        disk_rows = ""
        for d in disks:
            pct = d["percent"]
            bar_color = "#27ae60" if pct < 70 else ("#e67e22" if pct < 90 else "#e74c3c")
            disk_rows += f"""
            <tr>
              <td>{d['device']}</td>
              <td>{d['mountpoint']}</td>
              <td>{d['fstype']}</td>
              <td>{d['total_gb']:.1f} Go</td>
              <td>{d['free_gb']:.1f} Go</td>
              <td>
                <div style="background:#eee;border-radius:4px;height:12px;width:120px;overflow:hidden">
                  <div style="width:{pct}%;background:{bar_color};height:100%"></div>
                </div>
                {pct:.1f}%
              </td>
            </tr>"""

        # ── Interface rows ──
        iface_rows = ""
        for iface in ifaces:
            color = "#27ae60" if iface["status"] == "UP" else "#e74c3c"
            iface_rows += f"""
            <tr>
              <td>{iface['name']}</td>
              <td>{iface['ip']}</td>
              <td>{iface['netmask']}</td>
              <td style="color:{color};font-weight:600">{iface['status']}</td>
            </tr>"""

        # ── Category chart bars ──
        cat_bars = ""
        max_count = max(stats["by_category"].values(), default=1)
        for cat, count in sorted(stats["by_category"].items(), key=lambda x: -x[1]):
            w = int((count / max_count) * 200)
            cat_bars += f"""
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
              <div style="width:80px;font-size:.8rem;color:#555">{cat}</div>
              <div style="background:#0D1F3C;height:20px;width:{w}px;border-radius:4px"></div>
              <div style="font-weight:600;color:#0D1F3C">{count}</div>
            </div>"""

        html = f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Rapport IT — {now.strftime('%d/%m/%Y %H:%M')}</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Segoe UI',Arial,sans-serif;background:#F4F7FB;color:#1A1D27;font-size:14px}}
  header{{background:#0D1F3C;color:#fff;padding:32px 40px}}
  header h1{{font-size:1.6rem;margin-bottom:6px}}
  header p{{opacity:.6;font-size:.85rem}}
  .badge{{display:inline-block;background:#00B4CC;color:#0D1F3C;font-weight:700;
          font-size:.75rem;padding:3px 10px;border-radius:100px;margin-left:10px}}
  main{{padding:32px 40px;max-width:1100px;margin:0 auto}}
  h2{{font-size:1.1rem;color:#0D1F3C;margin:32px 0 16px;padding-bottom:8px;
      border-bottom:2px solid #00B4CC}}
  .cards{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:8px}}
  .card{{background:#fff;border:1px solid #D1D9E6;border-radius:10px;padding:20px;text-align:center}}
  .card-n{{font-size:2rem;font-weight:700;color:#0D1F3C}}
  .card-l{{font-size:.8rem;color:#888;margin-top:4px}}
  table{{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;
         box-shadow:0 1px 6px rgba(0,0,0,.06)}}
  th{{background:#0D1F3C;color:#fff;padding:10px 14px;text-align:left;font-size:.8rem;font-weight:600}}
  td{{padding:9px 14px;border-bottom:1px solid #eee;font-size:.82rem}}
  tr:last-child td{{border:none}}
  code{{background:#eef2f7;padding:2px 6px;border-radius:4px;font-size:.8rem}}
  .info-grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}
  .info-block{{background:#fff;border:1px solid #D1D9E6;border-radius:10px;padding:20px}}
  .info-block h3{{font-size:.9rem;font-weight:700;color:#0D1F3C;margin-bottom:12px}}
  .info-row{{display:flex;justify-content:space-between;font-size:.82rem;padding:5px 0;
             border-bottom:1px solid #f0f0f0}}
  .info-row span:last-child{{font-weight:600;color:#1A1D27}}
  footer{{text-align:center;padding:24px;color:#aaa;font-size:.78rem}}
</style>
</head>
<body>
<header>
  <h1>Rapport IT <span class="badge">v1.0</span></h1>
  <p>Généré le {now.strftime('%d/%m/%Y à %H:%M:%S')} · DOGLO Koami Justin · IT Helpdesk Toolkit</p>
</header>
<main>

  <h2>📊 Résumé des incidents</h2>
  <div class="cards">
    <div class="card"><div class="card-n">{stats['total']}</div><div class="card-l">Total tickets</div></div>
    <div class="card"><div class="card-n" style="color:#e67e22">{stats['open']}</div><div class="card-l">Ouverts</div></div>
    <div class="card"><div class="card-n" style="color:#27ae60">{stats['closed']}</div><div class="card-l">Clôturés</div></div>
  </div>

  <h2>📁 Incidents par catégorie</h2>
  <div style="background:#fff;border:1px solid #D1D9E6;border-radius:10px;padding:20px">
    {cat_bars if cat_bars else '<p style="color:#aaa">Aucun incident.</p>'}
  </div>

  <h2>🎫 Tous les tickets</h2>
  <table>
    <thead><tr>
      <th>ID</th><th>Titre</th><th>Catégorie</th><th>Priorité</th>
      <th>Statut</th><th>Utilisateur</th><th>Créé le</th>
    </tr></thead>
    <tbody>{rows_html if rows_html else '<tr><td colspan="7" style="text-align:center;color:#aaa">Aucun ticket.</td></tr>'}</tbody>
  </table>

  <h2>💻 Système d'exploitation</h2>
  <div class="info-grid">
    <div class="info-block">
      <h3>Identification</h3>
      <div class="info-row"><span>Nom d'hôte</span><span>{o['hostname']}</span></div>
      <div class="info-row"><span>FQDN</span><span>{o['fqdn']}</span></div>
      <div class="info-row"><span>OS</span><span>{o['system']} {o['release']}</span></div>
      <div class="info-row"><span>Architecture</span><span>{o['machine']}</span></div>
      <div class="info-row"><span>Uptime</span><span>{int(sys_data['uptime'].total_seconds()//3600)}h</span></div>
    </div>
    <div class="info-block">
      <h3>Processeur &amp; RAM</h3>
      <div class="info-row"><span>CPU</span><span>{cpu['name'][:40]}</span></div>
      <div class="info-row"><span>Cœurs</span><span>{cpu['cores_physical']}P / {cpu['cores_logical']}L</span></div>
      <div class="info-row"><span>Fréquence</span><span>{freq_str}</span></div>
      <div class="info-row"><span>RAM Total</span><span>{ram['total_gb']:.1f} Go</span></div>
      <div class="info-row"><span>RAM Dispo</span><span>{ram['free_gb']:.1f} Go</span></div>
      <div class="info-row"><span>RAM Usage</span><span>{ram['percent']}%</span></div>
    </div>
  </div>

  <h2>💾 Stockage</h2>
  <table>
    <thead><tr><th>Périphérique</th><th>Point de montage</th><th>Type</th><th>Total</th><th>Libre</th><th>Utilisation</th></tr></thead>
    <tbody>{disk_rows}</tbody>
  </table>

  <h2>🌐 Interfaces réseau</h2>
  <table>
    <thead><tr><th>Interface</th><th>Adresse IP</th><th>Masque</th><th>Statut</th></tr></thead>
    <tbody>{iface_rows}</tbody>
  </table>

</main>
<footer>IT Helpdesk Toolkit · github.com/justindoglo · {now.year}</footer>
</body>
</html>"""

        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

        return path
